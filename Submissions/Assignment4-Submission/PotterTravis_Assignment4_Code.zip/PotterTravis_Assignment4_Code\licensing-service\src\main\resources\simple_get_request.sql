SELECT * FROM licenses;
