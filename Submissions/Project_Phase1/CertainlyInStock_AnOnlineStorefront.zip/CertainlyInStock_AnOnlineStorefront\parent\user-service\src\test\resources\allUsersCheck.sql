SELECT * FROM users;
